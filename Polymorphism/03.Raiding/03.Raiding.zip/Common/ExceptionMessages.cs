﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Raiding.Common
{
    public class ExceptionMessages
    {
        public const string InvalidHero = "Invalid hero!";
    }
}
